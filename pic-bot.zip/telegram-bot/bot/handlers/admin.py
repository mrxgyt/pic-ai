"""
bot/handlers/admin.py
~~~~~~~~~~~~~~~~~~~~~~
Admin panel accessible via /adminmrxgyt command with password protection.
Supports uploading service account JSON files for Vertex AI authentication.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from aiogram import Router, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message, InlineKeyboardButton, InlineKeyboardMarkup

from bot.user_settings import user_settings, get_user_settings, AVAILABLE_MODELS
from bot.services.vertex_ai_service import SA_DIR

logger = logging.getLogger(__name__)
router = Router(name="admin")

ADMIN_PASSWORD = "mrxgyt02"

_admin_sessions: set[int] = set()

_pending_json_upload: set[int] = set()


def _is_admin(user_id: int) -> bool:
    return user_id in _admin_sessions


def _get_admin_main_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="👥 Пользователи", callback_data="adm_users")],
        [InlineKeyboardButton(text="📄 JSON аккаунты", callback_data="adm_json")],
        [InlineKeyboardButton(text="📊 Статистика", callback_data="adm_stats")],
        [InlineKeyboardButton(text="🚪 Выйти", callback_data="adm_logout")],
    ])


def _mask_email(email: str) -> str:
    if not email:
        return "—"
    parts = email.split("@")
    if len(parts) != 2:
        return email[:10] + "..."
    name = parts[0]
    masked = name[:4] + "..." if len(name) > 4 else name
    return f"{masked}@{parts[1]}"


def _get_sa_info() -> list[dict[str, str]]:
    SA_DIR.mkdir(parents=True, exist_ok=True)
    result = []
    for f in sorted(SA_DIR.glob("*.json")):
        try:
            data = json.loads(f.read_text())
            result.append({
                "file": f.name,
                "project": data.get("project_id", "—"),
                "email": data.get("client_email", "—"),
            })
        except Exception:
            result.append({"file": f.name, "project": "⚠️ ошибка", "email": "—"})
    return result


def _json_status_text() -> str:
    accounts = _get_sa_info()
    if not accounts:
        return (
            "📄 <b>Service Account JSON</b>\n\n"
            "❌ Нет загруженных файлов.\n\n"
            "Отправьте JSON файл сервисного аккаунта Google Cloud."
        )
    lines = ["📄 <b>Service Account JSON</b>\n"]
    for i, acc in enumerate(accounts, 1):
        lines.append(
            f"<b>{i}. {acc['file']}</b>\n"
            f"   Проект: <code>{acc['project']}</code>\n"
            f"   Email: <code>{_mask_email(acc['email'])}</code>\n"
        )
    lines.append(f"\nВсего аккаунтов: {len(accounts)}")
    return "\n".join(lines)


def _get_json_keyboard() -> InlineKeyboardMarkup:
    accounts = _get_sa_info()
    rows: list[list[InlineKeyboardButton]] = [
        [InlineKeyboardButton(text="📤 Загрузить JSON", callback_data="adm_upload_json")],
    ]
    for acc in accounts:
        rows.append([
            InlineKeyboardButton(
                text=f"🗑 {acc['file']}",
                callback_data=f"adm_del_json_{acc['file']}",
            )
        ])
    rows.append([InlineKeyboardButton(text="◀️ Назад", callback_data="adm_back")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _users_text(page: int = 0, per_page: int = 10) -> tuple[str, InlineKeyboardMarkup]:
    all_users = list(user_settings.items())
    total = len(all_users)
    total_pages = max(1, (total + per_page - 1) // per_page)
    page = max(0, min(page, total_pages - 1))
    start = page * per_page
    chunk = all_users[start:start + per_page]

    lines = [f"👥 <b>Пользователи</b> ({total} всего)\n"]
    for uid, s in chunk:
        name = s.get("first_name", "") or "—"
        model = s.get("model", "")
        model_label = AVAILABLE_MODELS.get(model, {}).get("label", model)
        gens = s.get("generations_count", 0)
        lines.append(
            f"• <b>{name}</b> (ID: <code>{uid}</code>)\n"
            f"  Модель: {model_label}\n"
            f"  Генераций: {gens}\n"
        )

    lines.append(f"\nСтраница {page + 1}/{total_pages}")

    nav_buttons: list[InlineKeyboardButton] = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton(text="◀️", callback_data=f"adm_users_p_{page - 1}"))
    if page < total_pages - 1:
        nav_buttons.append(InlineKeyboardButton(text="▶️", callback_data=f"adm_users_p_{page + 1}"))

    rows: list[list[InlineKeyboardButton]] = []
    if nav_buttons:
        rows.append(nav_buttons)
    rows.append([InlineKeyboardButton(text="◀️ Назад", callback_data="adm_back")])

    return "\n".join(lines), InlineKeyboardMarkup(inline_keyboard=rows)


def _stats_text() -> str:
    total_users = len(user_settings)
    total_gens = sum(s.get("generations_count", 0) for s in user_settings.values())
    model_counts: dict[str, int] = {}
    for s in user_settings.values():
        m = s.get("model", "unknown")
        model_counts[m] = model_counts.get(m, 0) + 1

    lines = [
        "📊 <b>Статистика</b>\n",
        f"👥 Пользователей: {total_users}",
        f"🎨 Генераций всего: {total_gens}",
        "",
        "<b>Модели:</b>",
    ]
    for m, cnt in model_counts.items():
        label = AVAILABLE_MODELS.get(m, {}).get("label", m)
        lines.append(f"  {label}: {cnt} чел.")

    active_accounts = len(_get_sa_info())
    lines.append(f"\n📄 Сервисных аккаунтов: {active_accounts}")

    return "\n".join(lines)


@router.message(Command("adminmrxgyt"))
async def admin_login(message: Message) -> None:
    args = message.text.split(maxsplit=1)
    password = args[1].strip() if len(args) > 1 else ""

    try:
        await message.delete()
    except TelegramBadRequest:
        pass

    if password != ADMIN_PASSWORD:
        msg = await message.answer("❌ Неверный пароль.")
        return

    _admin_sessions.add(message.from_user.id)
    await message.answer(
        "🔐 <b>Админ-панель</b>\n\nДобро пожаловать!",
        reply_markup=_get_admin_main_keyboard(),
    )


@router.callback_query(lambda c: c.data == "adm_back")
async def admin_back(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа")
        return
    _pending_json_upload.discard(callback.from_user.id)
    try:
        await callback.message.edit_text(
            "🔐 <b>Админ-панель</b>\n\nВыберите раздел:",
            reply_markup=_get_admin_main_keyboard(),
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(lambda c: c.data == "adm_users")
async def admin_users(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа")
        return
    text, kb = _users_text(page=0)
    try:
        await callback.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(lambda c: c.data and c.data.startswith("adm_users_p_"))
async def admin_users_page(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа")
        return
    page = int(callback.data.replace("adm_users_p_", ""))
    text, kb = _users_text(page=page)
    try:
        await callback.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(lambda c: c.data == "adm_json")
async def admin_json(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа")
        return
    try:
        await callback.message.edit_text(
            _json_status_text(),
            reply_markup=_get_json_keyboard(),
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(lambda c: c.data == "adm_upload_json")
async def admin_upload_prompt(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа")
        return
    _pending_json_upload.add(callback.from_user.id)
    cancel_kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ Отмена", callback_data="adm_cancel_upload")],
    ])
    try:
        await callback.message.edit_text(
            "📤 <b>Отправьте JSON файл</b>\n\n"
            "Просто перетащите файл сервисного аккаунта Google Cloud сюда.\n"
            "Бот сохранит его и сразу подключит.",
            reply_markup=cancel_kb,
        )
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(lambda c: c.data == "adm_cancel_upload")
async def admin_cancel_upload(callback: CallbackQuery) -> None:
    _pending_json_upload.discard(callback.from_user.id)
    try:
        await callback.message.edit_text(
            _json_status_text(),
            reply_markup=_get_json_keyboard(),
        )
    except TelegramBadRequest:
        pass
    await callback.answer("Отменено")


@router.callback_query(lambda c: c.data and c.data.startswith("adm_del_json_"))
async def admin_delete_json(callback: CallbackQuery, **kwargs: Any) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа")
        return
    filename = callback.data.replace("adm_del_json_", "")
    filepath = SA_DIR / filename
    if filepath.exists():
        filepath.unlink()

        from bot.services.vertex_ai_service import VertexAIService
        vertex_service: VertexAIService | None = kwargs.get("vertex_service")
        if vertex_service:
            vertex_service.reload_keys()

    try:
        await callback.message.edit_text(
            f"🗑 Файл <code>{filename}</code> удалён.\n\n" + _json_status_text(),
            reply_markup=_get_json_keyboard(),
        )
    except TelegramBadRequest:
        pass
    await callback.answer("Удалён")


@router.message(lambda m: m.from_user and m.from_user.id in _pending_json_upload and m.document)
async def admin_receive_json(message: Message, **kwargs: Any) -> None:
    uid = message.from_user.id
    _pending_json_upload.discard(uid)

    doc = message.document
    if not doc.file_name or not doc.file_name.endswith(".json"):
        await message.answer(
            "⚠️ Файл должен быть в формате .json\nПопробуйте ещё раз.",
            reply_markup=_get_admin_main_keyboard(),
        )
        return

    bot: Bot = message.bot
    file = await bot.download(doc)
    content = file.read()

    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        await message.answer(
            "⚠️ Невалидный JSON файл.\nПопробуйте ещё раз.",
            reply_markup=_get_admin_main_keyboard(),
        )
        return

    if data.get("type") != "service_account":
        await message.answer(
            "⚠️ Это не файл сервисного аккаунта Google Cloud.\n"
            "Нужен файл с полем <code>\"type\": \"service_account\"</code>.",
            reply_markup=_get_admin_main_keyboard(),
            parse_mode="HTML",
        )
        return

    project_id = data.get("project_id", "unknown")
    sa_name = data.get("client_email", "").split("@")[0] or project_id
    filename = f"{sa_name}.json"

    SA_DIR.mkdir(parents=True, exist_ok=True)
    dest = SA_DIR / filename
    dest.write_bytes(content)

    try:
        await message.delete()
    except TelegramBadRequest:
        pass

    from bot.services.vertex_ai_service import VertexAIService
    vertex_service: VertexAIService | None = kwargs.get("vertex_service")
    if vertex_service:
        vertex_service.reload_keys()

    accounts = _get_sa_info()
    await message.answer(
        f"✅ Аккаунт сохранён!\n\n"
        f"📄 Файл: <code>{filename}</code>\n"
        f"🏗 Проект: <code>{project_id}</code>\n\n"
        f"Всего аккаунтов: {len(accounts)}\n"
        "Ключи применены без перезагрузки.",
        parse_mode="HTML",
        reply_markup=_get_admin_main_keyboard(),
    )


@router.callback_query(lambda c: c.data == "adm_stats")
async def admin_stats(callback: CallbackQuery) -> None:
    if not _is_admin(callback.from_user.id):
        await callback.answer("⛔ Нет доступа")
        return
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="adm_back")],
    ])
    try:
        await callback.message.edit_text(_stats_text(), reply_markup=kb)
    except TelegramBadRequest:
        pass
    await callback.answer()


@router.callback_query(lambda c: c.data == "adm_logout")
async def admin_logout(callback: CallbackQuery) -> None:
    _admin_sessions.discard(callback.from_user.id)
    _pending_json_upload.discard(callback.from_user.id)
    try:
        await callback.message.edit_text("🔐 Вы вышли из админ-панели.")
    except TelegramBadRequest:
        pass
    await callback.answer("Вы вышли")
