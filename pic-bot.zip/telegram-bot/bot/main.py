"""
bot/main.py
~~~~~~~~~~~
Entry point for the Telegram image-generation bot.

Responsibilities:
  - Load configuration via pydantic-settings.
  - Configure structured logging.
  - Build the aiogram Bot + Dispatcher.
  - Register middlewares, handlers, and dependency injections.
  - Start long-polling.
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

from bot.config import get_settings
from bot.handlers import admin as admin_handler
from bot.handlers import callbacks as callbacks_handler
from bot.handlers import creative as creative_handler
from bot.handlers import image as image_handler
from bot.handlers import start as start_handler
from bot.middlewares.album_middleware import AlbumMiddleware
from bot.middlewares.logging_middleware import LoggingMiddleware
from bot.services.vertex_ai_service import VertexAIService
from bot.user_settings import load_settings


def _configure_logging() -> None:
    """Set up a sensible default logging configuration."""
    log_level = os.getenv("LOG_LEVEL", "INFO").upper()
    logging.basicConfig(
        level=getattr(logging, log_level, logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        stream=sys.stdout,
    )
    # Quieten noisy third-party loggers
    logging.getLogger("aiogram").setLevel(logging.WARNING)
    logging.getLogger("aiohttp").setLevel(logging.WARNING)


async def main() -> None:
    _configure_logging()
    logger = logging.getLogger(__name__)

    settings = get_settings()
    load_settings()
    logger.info("Starting Telegram bot (model=%s)", settings.vertex_ai_model)

    # ── Vertex AI service ────────────────────────────────────────────────────
    vertex_service = VertexAIService(settings)

    # ── Aiogram bot & dispatcher ─────────────────────────────────────────────
    bot = Bot(
        token=settings.telegram_bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()

    # ── Middlewares ───────────────────────────────────────────────────────────
    dp.update.outer_middleware(LoggingMiddleware())
    dp.message.middleware(AlbumMiddleware())

    # ── Dependency injection ──────────────────────────────────────────────────
    # Inject vertex_service into every handler that declares the parameter.
    dp["vertex_service"] = vertex_service

    # ── Routers ───────────────────────────────────────────────────────────────
    dp.include_router(start_handler.router)
    dp.include_router(admin_handler.router)
    dp.include_router(creative_handler.router)
    dp.include_router(callbacks_handler.router)
    dp.include_router(image_handler.router)

    # ── Start polling ─────────────────────────────────────────────────────────
    logger.info("Bot is running. Press Ctrl+C to stop.")
    try:
        await dp.start_polling(bot, allowed_updates=["message", "callback_query"])
    finally:
        await bot.session.close()
        logger.info("Bot stopped.")


if __name__ == "__main__":
    asyncio.run(main())
